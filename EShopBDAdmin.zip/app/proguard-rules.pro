# Keep JS Bridge methods
-keepclassmembers class com.eshopbd.admin.MainActivity$AndroidAppBridge {
    @android.webkit.JavascriptInterface <methods>;
}
