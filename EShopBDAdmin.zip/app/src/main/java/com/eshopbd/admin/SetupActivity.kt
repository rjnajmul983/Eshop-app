package com.eshopbd.admin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.net.HttpURLConnection
import java.net.URL

class SetupActivity : AppCompatActivity() {

    private lateinit var etShopName: TextInputEditText
    private lateinit var etBaseUrl: TextInputEditText
    private lateinit var etApiKey: TextInputEditText
    private lateinit var tvStatus: TextView
    private lateinit var progressTest: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        etShopName = findViewById(R.id.etShopName)
        etBaseUrl = findViewById(R.id.etBaseUrl)
        etApiKey = findViewById(R.id.etApiKey)
        tvStatus = findViewById(R.id.tvStatus)
        progressTest = findViewById(R.id.progressTest)

        etShopName.setText(AppConfig.getShopName(this))
        val savedUrl = AppConfig.getBaseUrl(this)
        if (savedUrl.isNotBlank()) etBaseUrl.setText(savedUrl)
        etApiKey.setText(AppConfig.getApiKey(this))

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener { testConnection() }
        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener { saveAndOpen() }
    }

    private fun normalizeUrl(raw: String): String {
        var u = raw.trim().trimEnd('/')
        if (u.endsWith("/admin")) u = u.removeSuffix("/admin")
        if (u.endsWith("/api/v1")) u = u.removeSuffix("/api/v1")
        if (u.isNotBlank() && !u.startsWith("http://") && !u.startsWith("https://")) {
            u = "https://$u"
        }
        return u.trimEnd('/')
    }

    private fun testConnection() {
        val urlStr = normalizeUrl(etBaseUrl.text?.toString().orEmpty())
        val apiKey = etApiKey.text?.toString()?.trim().orEmpty()
        if (urlStr.isBlank()) {
            showStatus("আগে আপনার ওয়েবসাইটের লিংক দিন।", false)
            return
        }
        etBaseUrl.setText(urlStr)
        progressTest.visibility = View.VISIBLE
        tvStatus.visibility = View.GONE

        Thread {
            try {
                val conn = (URL("$urlStr/admin").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    instanceFollowRedirects = true
                    if (apiKey.isNotBlank()) {
                        setRequestProperty("X-API-Key", apiKey)
                    }
                }
                val code = conn.responseCode
                conn.disconnect()
                runOnUiThread {
                    progressTest.visibility = View.GONE
                    if (code in 200..399) {
                        showStatus("সফলভাবে কানেক্ট হয়েছে (HTTP $code)। এখন সেভ বাটনে ট্যাপ করুন।", true)
                    } else {
                        showStatus("সার্ভার থেকে HTTP $code পাওয়া গেছে। লিংকটি আবার যাচাই করুন।", false)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progressTest.visibility = View.GONE
                    showStatus("কানেক্ট করা যায়নি: ${e.localizedMessage ?: "নেটওয়ার্ক ত্রুটি"}", false)
                }
            }
        }.start()
    }

    private fun saveAndOpen() {
        val shopName = etShopName.text?.toString().orEmpty()
        val urlStr = normalizeUrl(etBaseUrl.text?.toString().orEmpty())
        val apiKey = etApiKey.text?.toString().orEmpty()

        if (urlStr.isBlank() || !urlStr.startsWith("http")) {
            Toast.makeText(this, "সঠিক ওয়েবসাইট লিংক দিন (https://...)", Toast.LENGTH_SHORT).show()
            return
        }

        AppConfig.save(this, shopName, urlStr, apiKey)
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }

    private fun showStatus(message: String, ok: Boolean) {
        tvStatus.visibility = View.VISIBLE
        tvStatus.text = message
        tvStatus.setTextColor(
            ContextCompat.getColor(this, if (ok) R.color.success_green else R.color.error_red)
        )
    }
}
