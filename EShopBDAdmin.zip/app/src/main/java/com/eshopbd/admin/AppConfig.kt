package com.eshopbd.admin

import android.content.Context

object AppConfig {
    private const val PREF_NAME = "eshopbd_admin_prefs"
    private const val KEY_BASE_URL = "base_url"
    private const val KEY_API_KEY = "api_key"
    private const val KEY_SHOP_NAME = "shop_name"

    fun isConfigured(context: Context): Boolean {
        return getBaseUrl(context).isNotBlank()
    }

    fun getBaseUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_BASE_URL, "")?.trim()?.trimEnd('/') ?: ""
    }

    fun getApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_API_KEY, "")?.trim() ?: ""
    }

    fun getShopName(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_SHOP_NAME, "E-ShopBD Admin")?.trim().orEmpty()
            .ifBlank { "E-ShopBD Admin" }
    }

    fun save(context: Context, shopName: String, baseUrl: String, apiKey: String) {
        val cleanUrl = baseUrl.trim().trimEnd('/')
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_SHOP_NAME, shopName.trim().ifBlank { "E-ShopBD Admin" })
            .putString(KEY_BASE_URL, cleanUrl)
            .putString(KEY_API_KEY, apiKey.trim())
            .apply()
    }
}
